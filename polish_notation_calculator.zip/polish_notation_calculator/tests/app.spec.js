describe('Testing Controller', function(){
	beforeEach(angular.mock.module('postfixApp'));

    var $controller, $scope, controller;
	
    beforeEach(inject(function(_$controller_){
    $controller = _$controller_;
    }));
	 
	beforeEach(function() {
      $scope = {};
      controller = $controller('PostFixController', { $scope: $scope });
    });
	
	it('should return postfix evaluation 9 if the input expression is 5 4 +', function() {
      $scope.expression = '5 4 +';
      $scope.output = $scope.evaluate($scope.expression);
      expect($scope.output).toEqual(9);
    });
	it('should return postfix evaluation 11 if the input expression is 2 3 + 4 4 * -', function() {
      $scope.expression = '2 3 + 4 4 * -';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual(11);
    });
	it('should return postfix evaluation 4 if the input expression is -4 8 +', function() {
      $scope.expression = '-5 6 +';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual(4);
    });
	it('should return postfix evaluation 8 if the input expression is -2 -7 + 5 4 * /', function() {
      $scope.expression = '-2 -7 + 5 4 * /';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual(-0.45);
    });
	it('should return 12 if the input expression is 60 5 /', function() {
      $scope.expression = '60 5 /';
	  $scope.output = $scope.postfixEvaluator($scope.expression);
	  expect($scope.output).toEqual("12");
    });
	it('should return error if the input expression is x ', function() {
      $scope.expression = 'x ';
      $scope.output = $scope.postfixEvaluator($scope.expression);
      expect($scope.output).toEqual("Unable to process");
    });
	it('should return error if the input expression is 14 / * +', function() {
      $scope.expression = '14 / * +';
	  $scope.output = $scope.postfixEvaluator($scope.expression);
	  expect($scope.output).toEqual("Unable to process");
    }); 
});